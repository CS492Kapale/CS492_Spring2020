/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unstable.bunnies;
        
/**
 *
 * @author brandon
 */
public class UnstableBunnies { 
static String [] Questions = new String[60];
static int player1 = 0;
static int player2 = 0;
static int player3 = 0;
static int prior = 0;
//static String player1Name = "";
//static String player2Name = "";
//static String player3Name = "";
    public static void main(String[] args) {
        
        Login PES = new Login();
        PES.setVisible(true);
        
        
    }
    public static void valid(int verify){
        if (verify == 1){
        NameGUI Name = new NameGUI();
        Name.setVisible(true);
        }
        }
    public static void Change(){
        Credentials cred = new Credentials();
        cred.setVisible(true);
    }
    public static String getQuestion(int i){
        
        return Questions[i];
    }
    public static void Startup(String [] names){
        String player1 = names[0];
        String player2 = names[1];
        String player3 = names[2];
        QuestionGUI  Game = new QuestionGUI();
        Game.setVisible(true);
    }
    public static String getPlayer(){
        String player = "Not Available";
        int position = (int)(Math.random() * ((3 - 1) + 1)) + 1;
        while(prior == position){
            position = (int)(Math.random() * ((3 - 1) + 1)) + 1;
        }
        if (position == 1){
            player = "Player1";
        }
        if (position == 2){
            player = "Player2";
        }
        if (position == 3){
            player = "Player3";
        }
        prior = position;
        
        return player;
    }
    
    public static void setScores(int score, int score2, int score3){
        player1 = score;
        player2 = score2;
        player3 = score3;
    }
    public static int getScore1(){
        return player1;
        
    }
    public static int getScore2(){
        return player2;
        
    }
    public static int getScore3(){
        return player3;
        
    }
    
    public static String[] makeQuestions(int value){
       // Randomizer for later
        /*int size = Questions.length;
        for( int i = 0; i < size; i++){
            
        }*/
        if(value == 1){        
            Questions[1] = "What gets me out of bed?";
            Questions[2] = "I drink to forget _______.";
            Questions[3] = "What I'm marrying _______!";
            Questions[4] = "I learned the hard way never bribe an officer with _____.";
            Questions[5] = "I've got 99 problems but ___ ain't one.";
            Questions[6] = "The worst thing I ever said during a spanking was ______.";
            Questions[7] = "Having the worst day ever. #______";
            Questions[8] = "______ best thing for a family!";
            Questions[9] = "Now showing at the Dolby Theater _________ The Musical!";
            Questions[10] = "_____ what would a girl do without it.";
            Questions[11] = "______! That's white people shit!";
            Questions[12] = "During sex my mind often thinks about _____.";
            Questions[13] = "Stop being such a baby it's only ____.";
            Questions[14] = "Bigfoot is real damn it, and he _____.";
            Questions[15] = "Here is the church, here is the steeple. Open the door and there is the ____.";
            Questions[16] = "What is Donald Trump doint right now?";
            Questions[17] = "When I was your age all we had was ______.";
            Questions[18] = "______ always comes when you least expect it.";
            Questions[19] = "I'm sorry to tell you but you have _____.";
            Questions[20] = "Off all the superpowers and I'm stuck with _______.";
            Questions[21] = "______. Yep thats how I die";
            Questions[22] = "Happiness is just a hop, skip and _____ away.";
            Questions[23] = "Sex is good and all but have you tried ______";
            Questions[24] = "______ is not just a thing it's a lifestyle.";
            Questions[25] = "What ended my last relationship?";
            Questions[26] = "Next one ESPN2: The World Series of ______.";
            Questions[27] = "War! What is it good for?";
            Questions[28] = "What don't you want to find in your Chinese food?";
            Questions[29] = "What will always get you laid?";
            Questions[30] = "What I learned in college is _______.";
            Questions[31] = "_______. The lie detector determined that was a lie.";
            Questions[32] = "My childhood was ruined when I learned ______.";
            Questions[33] = "What killed my innocence?";
            Questions[34] = "What did I bring back from Mexico?";
            Questions[35] = "Next on Doctor Phil: How to talk to your kids about _____.";
            Questions[36] = "Quick! Get ______ into the van!";
            Questions[37] = "Make _____ Great Again!";
            Questions[38] = "I went to the woods to learn peace but, I only found ______.";
            Questions[39] = "I swear officer I was drunk I would never do ______ sober.";
            Questions[40] = "What was my greatest failure?";
            Questions[41] = "You should have been _______.";
            Questions[42] = "What was my childhood fear?";
            Questions[43] = "Leave _____ alone that's my prized possesion!";
            Questions[44] = "I can't help it ______ feels so good!";
            Questions[45] = "I cannot believe my teacher assigned us to _______.";
            Questions[46] = "The test has determined you are _______.";
            Questions[47] = "_____ and that kids is how I met your mother.";
            Questions[48] = "What is my dream job?";
            Questions[49] = "The only job I'm qualified for is _______.";
            Questions[50] = "And on the 8th day God created ______.";
            Questions[51] = "I lock my phone to hide _______";
            Questions[52] = "Is that a _____ in your pocket or are you happy to see me?";
            Questions[53] = "I can't believe ______ wants to go out tonight!";
            Questions[54] = "Why does my dick/vagina hurt";
            Questions[55] = "Where's my fuckboy?";
            Questions[56] = "Why is my back sore??";
            Questions[57] = "Whats that stain?";
            Questions[58] = "What is that smell?";
            Questions[59] = "What made my first kiss so awkward?";
            Questions[0] = "What made my last kiss so awkward?";
        }
        else if(value == 2){
                Questions[1] = "Where is my roommate?";
                Questions[2] = "I drink to forget _______.";
                Questions[3] = "The bar serves how young?";
                Questions[4] = "I learned the hard way never bribe an officer with _____.";
                Questions[5] = "I've got 99 problems but ___ ain't one.";
                Questions[6] = "Why is my RA at my door.";
                Questions[7] = "Why is the police at my door?";
                Questions[8] = "Today in class my proffesor ________.";
                Questions[9] = "My best friend is ______";
                Questions[10] = "I smoke to get over ____. ";
                Questions[11] = "I'm really ______ while drunk.";
                Questions[12] = "During class I often think about ______";
                Questions[13] = "The class I always cheated in was______";
                Questions[14] = "I was voted most likely to ____ in college";
                Questions[15] = "I was voted King of ________";
                Questions[16] = "Why did the Homecoming King Vanish?";
                Questions[17] = "I can't believe the Freshman class ________";
                Questions[18] = "I'd even _______ to get an A";
                Questions[19] = "My degree comes from hard work and _____";
                Questions[20] = "Off all the teachers and I'm stuck with _______.";
                Questions[21] = "Homework sure is a _______";
                Questions[22] = "The freshmen class is sure full of ______";
                Questions[23] = "Man that dorm food sure is _______";
                Questions[24] = "Drugs Sex and _______";
                Questions[25] = "What ended my last relationship?";
                Questions[26] = "My ex sure was a _______";
                Questions[27] = "_____ sure is cheaper off campus";
                Questions[28] = "What don't you want to find in your roommates fridge?";
                Questions[29] = "What will always get you laid?";
                Questions[30] = "What I learned in college is _______.";
                Questions[31] = "College the only place you find ____ in a cupcake.";
                Questions[32] = "My innocence was ruined when I learned of ______.";
                Questions[33] = "What killed my GPA?";
                Questions[34] = "What did I bring back from Spring Break?";
                Questions[35] = "A college students best friend is _____.";
                Questions[36] = "Walmart the number one provider of _____";
                Questions[37] = "Why is my homework late?";
                Questions[38] = "My ____ ate my homework";
                Questions[39] = "I swear officer I was drunk I would never do ______ sober.";
                Questions[40] = "What was my greatest failure?";
                Questions[41] = "You should have been _______.";
                Questions[42] = "What was my college fear?";
                Questions[43] = "It's because of _____ I dropped out";
                Questions[44] = "I only pass classes do to my _______";
                Questions[45] = "I cannot believe my teacher assigned us to _______.";
                Questions[46] = "The test has determined you are _______.";
                Questions[47] = "Why are my pants missing _____.";
                Questions[48] = "Who is in my bed?";
                Questions[49] = "Why are you in my bed?";
                Questions[50] = "And on the 8th day my teacher assigned c ______.";
                Questions[51] = "I lock my phone to hide _______";
                Questions[52] = "My teacher assigned _____ over spring break";
                Questions[53] = "I can't believe ______ wants to go out tonight!";
                Questions[54] = "My college motto is _________";
                Questions[55] = "What caused the fire alarm?";
                Questions[56] = "Only in college is ____ passed off as food";
                Questions[57] = "I'm only late to class because of _______";
                Questions[58] = "I'm sorry I'm late I had to  _______";
                Questions[59] = "How is _____ not extra credit";
                Questions[0] = "What is our univeristy known for?";
            }
        
        shuffleAlternate(Questions);
        return Questions;
        
        
    }
    public static void shuffleAlternate(Object[] a) { //Knuth Shuffle
        int n = a.length;
        for (int i = 0; i < n; i++) {
            // choose index uniformly in [i, n-1]
            int r = i + (int) (Math.random() * (n - i));
            Object swap = a[r];
            a[r] = a[i];
            a[i] = swap;
        }
    }
    }
    
    
    
